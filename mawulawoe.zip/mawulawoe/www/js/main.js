(function(){
    var val = prompt("Nombre ?");
    var premier = nbrPremier(val);
    afficher(premier);
})();

/*function main(){
    var val = document.getElementById("nbr").val;
    var premier = nbrPremier(val);
    afficher(premier);
}*/
