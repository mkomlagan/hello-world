(function(){
    var tab = document.createElement('table');
    for (var i = 0; i < 10; i++) {
        var l = document.createElement('tr');      
        for (var j = 0; j < 9; j++) {
            var c = document.createElement('td');
            l.appendChild(c);
        }
        tab.appendChild(l);
    }    
    document.body.appendChild(tab);
    
    for (var i = 0; i < 5; i++) {
        var l = Math.random()*10;     
        for (var j = 0; j < 3; j++) {
            var c = Math.random()*10;
            tab
        }
        tab.appendChild(l);
    } 
    
})();