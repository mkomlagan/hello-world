(function(){
    var form1 = document.createElement('form');
    form1.setAttribute('method', 'POST');
    form1.setAttribute('action', '../pages/formulaire.html');
    form1.setAttribute('id', 'form1');
    
    var input1 = document.createElement('input');
    input1.setAttribute('id', 'rouge');
    input1.setAttribute('name', 'rouge');
    input1.setAttribute('type','text');
    
    var input2 = document.createElement('input');
    input2.setAttribute('id', 'vert');
    input2.setAttribute('name', 'vert');
    input2.setAttribute('type','text');
        
    var input3 = document.createElement('input');
    input3.setAttribute('id', 'valider');
    input3.setAttribute('type','submit');
    
    var input4 = document.createElement('input');
    input4.setAttribute('id', 'valider');
    input4.setAttribute('type','button');
    input4.setAttribute('value','Dupliquer');
    
    var fieldset = document.createElement('fieldset');
    fieldset.setAttribute('id', 'form');
    var legend = document.createElement('legend');
    var formulaire = document.createTextNode('Formulaire');
    
    document.body.appendChild(fieldset);
    fieldset.appendChild(legend);
    legend.appendChild(formulaire);
    fieldset.appendChild(form1);
    form1.appendChild(input1);
    form1.appendChild(input2);
    form1.appendChild(input3);
    
    var hr = document.createElement('hr');
    document.body.appendChild(hr);
    
    document.body.appendChild(input4);
    
    var hr = document.createElement('hr');
    document.body.appendChild(hr);
    
    input4.addEventListener('click', function(){
        var dup = fieldset.cloneNode(true);
        document.body.appendChild(dup);
        var hr = document.createElement('hr');
        document.body.appendChild(hr);
    }, false);
    
    
})();