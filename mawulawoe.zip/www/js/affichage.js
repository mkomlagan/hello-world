function afficher(premier) {
    document.write(premier);
}