
function nbrPremier(nbr){
    
    if (nbr==0) {
        return false;
    }
    
    if (nbr==1) {
        return false;
    }
    
    if (nbr==2) {
        return true;
    }
    
    if (nbr%2==0) {
        return false;
    }
    
    else {
        for (var i = 2; i <= Math.sqrt(nbr) ; i++) {
            if(nbr%i==0){
                return false;
            }            
        }
        return true;
    }
}